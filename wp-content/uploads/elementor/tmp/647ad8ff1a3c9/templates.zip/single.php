<?php get_template_part( 'templates/single', "post-standard" );

