<?php namespace MetzWeb\Instagram\Exceptions;

use Exception;

class InstagramException extends Exception
{

}
