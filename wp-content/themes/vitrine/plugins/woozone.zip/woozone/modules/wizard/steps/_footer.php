<?php require( $this->module_folder_path . 'steps/_footer_html.php' ); ?>

</div><!-- end container -->

</div><!-- end ajax main container-->

				<?php
					//wp_print_media_templates();
					wp_print_footer_scripts();
				?>

			</body>
			</html>