=== EpicoMedia core ===
